<?php

namespace App\Http\Resources;

class RoleResource extends BaseJsonResource
{
}
