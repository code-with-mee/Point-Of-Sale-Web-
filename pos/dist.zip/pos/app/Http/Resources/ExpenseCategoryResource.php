<?php

namespace App\Http\Resources;

/**
 * Class ExpenseCategoryResource
 */
class ExpenseCategoryResource extends BaseJsonResource
{
}
