<?php

namespace App\Http\Resources;

/**
 * Class SmsTemplateResource
 */
class SmsTemplateResource extends BaseJsonResource
{
}
