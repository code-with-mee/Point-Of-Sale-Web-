<?php

namespace App\Http\Resources;

/**
 * Class POSRegisterResource
 */
class POSRegisterResource extends BaseJsonResource
{
}
