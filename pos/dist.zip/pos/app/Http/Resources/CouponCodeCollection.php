<?php

namespace App\Http\Resources;

/**
 * Class CouponCodeCollection
 */
class CouponCodeCollection extends BaseCollection
{
    public $collects = CouponCodeResource::class;
}
