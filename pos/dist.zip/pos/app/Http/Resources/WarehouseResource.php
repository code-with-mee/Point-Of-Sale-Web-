<?php

namespace App\Http\Resources;

/**
 * Class WarehouseResource
 */
class WarehouseResource extends BaseJsonResource
{
}
