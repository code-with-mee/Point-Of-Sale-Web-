<?php

namespace App\Http\Resources;

/**
 * Class ExpenseResource
 */
class ExpenseResource extends BaseJsonResource
{
}
