<?php

namespace App\Http\Resources;

/**
 * Class SaleCollection
 */
class SaleReturnCollection extends BaseCollection
{
    public $collects = SaleReturnResource::class;
}
