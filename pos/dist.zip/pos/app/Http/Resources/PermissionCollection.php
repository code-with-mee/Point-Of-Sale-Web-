<?php

namespace App\Http\Resources;

/**
 * Class PermissionCollection
 */
class PermissionCollection extends BaseCollection
{
    public $collects = PermissionResource::class;
}
