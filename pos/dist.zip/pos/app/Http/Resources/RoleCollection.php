<?php

namespace App\Http\Resources;

class RoleCollection extends BaseCollection
{
    public $collects = RoleResource::class;
}
