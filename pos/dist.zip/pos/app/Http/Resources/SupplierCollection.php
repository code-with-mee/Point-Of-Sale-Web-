<?php

namespace App\Http\Resources;

/**
 * Class SupplierCollection
 */
class SupplierCollection extends BaseCollection
{
    public $collects = SupplierResource::class;
}
