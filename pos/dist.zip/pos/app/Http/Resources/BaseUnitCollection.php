<?php

namespace App\Http\Resources;

/**
 * Class BaseUnitCollection
 */
class BaseUnitCollection extends BaseCollection
{
    public $collects = BaseUnitResource::class;
}
