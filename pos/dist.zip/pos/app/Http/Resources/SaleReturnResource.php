<?php

namespace App\Http\Resources;

/**
 * Class SaleResource
 */
class SaleReturnResource extends BaseJsonResource
{
}
