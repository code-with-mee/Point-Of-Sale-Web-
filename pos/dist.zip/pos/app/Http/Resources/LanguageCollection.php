<?php

namespace App\Http\Resources;

/**
 * Class LanguageCollection
 */
class LanguageCollection extends BaseCollection
{
    public $collects = LanguageResource::class;
}
