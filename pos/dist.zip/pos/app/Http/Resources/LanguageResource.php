<?php

namespace App\Http\Resources;

/**
 * Class LanguageResource
 */
class LanguageResource extends BaseJsonResource
{
}
